import React from 'react';
import 'antd/dist/antd.css';
import './index.css';
import { Card } from 'antd';
import Films from './Films.js';
/*<Pelicula pelicula={p}/>*/
/*const Peliculas = () => {
    return (
        <div>
            <Card title="Peliculas" style={{ width: 300 }}>
                <Films/>
            </Card>
        </div>
    );
}*/

//export default Peliculas;